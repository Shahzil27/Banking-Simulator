
import java.awt.*;    
import javax.swing.*;   
import javax.swing.JFrame;
import java.awt.event.*;

public class SimulatorGUI extends JFrame   {
	
	private TextField usernameInput;
	private TextField passwordInput;
	private TextField chequingWithdrawAmount;
	private TextField savingsWithdrawAmount;
	private TextField chequingDepositAmount;
	private TextField savingsDepositAmount;
	private JButton submitLogin;
	private JButton selectBalance;
	private JButton selectWithdraw;
	private JButton selectDeposit;
	private JButton selectTransfer;
	private JButton selectLogout;
	private JButton confirmWithdrawChequing;
	private JButton confirmWithdrawSavings;
	private JButton confirmDepositChequing;
	private JButton confirmDepositSavings;
	private JButton selectBack;
	private JButton confirmTransfer;
	private JComboBox<String[]> transferFrom;
	private JComboBox<String[]> transferTo;
	private boolean creationError;
	private boolean loginError;
	private boolean loggedOut;
	private String[] comboBoxArray = {"Chequing", "Savings"};
	
	
	public void createLoginPage() {

		setLayout(new GridLayout(6, 2));
		
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		
		if(creationError == true) {
			
			add(new JLabel(""));
			add(new JLabel("Error! Password must contain an uppercase"));
			
			add(new JLabel(""));
			add(new JLabel("letter, a number, and a symbol."));
		}
		
		else {
	
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		add(new JLabel(""));
		}
		
		add(new JLabel("Username:"));
		usernameInput = new TextField();
		add(usernameInput);
		
		add(new JLabel("Password:"));
		passwordInput = new TextField();
		add(passwordInput);
		
		add(new JLabel(""));
		submitLogin = new JButton("Create Account");
		add(submitLogin);
		submitLogin.addActionListener(new createAccountListener());
		creationError = false;

	}
	
	public void loginPage() {
			
		setLayout(new GridLayout(6, 2));
		
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		
		if(loginError == true) {
			
			add(new JLabel(""));
			add(new JLabel("Error! incorrect login credentials"));
			
			add(new JLabel(""));
			add(new JLabel(""));
		}
		
		else if(loggedOut == true) {
			add(new JLabel(""));
			add(new JLabel(""));
			
			add(new JLabel(""));
			add(new JLabel(""));
		}
		
		else {
			
			add(new JLabel(""));
			add(new JLabel("Account Successfully Created!"));
			
			add(new JLabel(""));
			add(new JLabel("Please Login"));
		}
		
		add(new JLabel("Username:"));
		usernameInput = new TextField();
		add(usernameInput);
		
		add(new JLabel("Password:"));
		passwordInput = new TextField();
		add(passwordInput);
		
		add(new JLabel(""));
		submitLogin = new JButton("Login");
		add(submitLogin);
		submitLogin.addActionListener(new loginListener());
		loginError = false;
		loggedOut = false;
			
	}
	
	public void homePage() {
		
		setLayout(new GridLayout(6, 3));
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		add(new JLabel("Welcome, Quinn"));
		
		add(new JLabel(""));
		selectBalance = new JButton("Check Balance");
		add(selectBalance);
		selectBalance.addActionListener(new checkBalanceListener());
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectWithdraw = new JButton("Withdraw");
		add(selectWithdraw);
		selectWithdraw.addActionListener(new withdrawListener());
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectDeposit = new JButton("Deposit");
		add(selectDeposit);
		selectDeposit.addActionListener(new depositListener());
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectTransfer = new JButton("Transfer Funds");
		add(selectTransfer);
		selectTransfer.addActionListener(new transferListener());
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectLogout = new JButton("Logout");
		add(selectLogout);
		add(new JLabel(""));
		selectLogout.addActionListener(new logOutListener());

	}
	
	public void checkBalancePage() {
		
		setLayout(new GridLayout(0, 3));
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		add(new JLabel("Welcome, Quinn"));
		
		add(new JLabel(""));
		add(new JLabel("Account Balance"));
		add(new JLabel(""));
		
		add(new JLabel("Chequing:"));
		add(new JLabel("Current Balance"));
		add(new JLabel(""));
		
		add(new JLabel("Savings:"));
		add(new JLabel("Current Balance"));
		add(new JLabel(""));
		
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectBack = new JButton("Back");
		add(selectBack);
		add(new JLabel(""));
		selectBack.addActionListener(new backButtonListener());

		}
	
	public void withdrawPage() {
		
		setLayout(new GridLayout(0, 3));
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		add(new JLabel("Welcome, Quinn"));
		
		add(new JLabel(""));
		add(new JLabel("Withdraw"));
		add(new JLabel(""));
		
		add(new JLabel("Chequing: Balance"));
		chequingWithdrawAmount = new TextField();
		add(chequingWithdrawAmount);
		confirmWithdrawChequing = new JButton("Confirm Withdraw");
		add(confirmWithdrawChequing);
		
		add(new JLabel("Savings: Balance"));
		savingsWithdrawAmount = new TextField();
		add(savingsWithdrawAmount);
		confirmWithdrawSavings = new JButton("Confirm Withdraw");
		add(confirmWithdrawSavings);
		
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectBack = new JButton("Back");
		add(selectBack);
		add(new JLabel(""));
		selectBack.addActionListener(new backButtonListener());

		}

	public void depositPage() {
		
		setLayout(new GridLayout(0, 3));
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		add(new JLabel("Welcome, Quinn"));
		
		add(new JLabel(""));
		add(new JLabel("Deposit"));
		add(new JLabel(""));
		
		add(new JLabel("Chequing: Balance"));
		chequingDepositAmount = new TextField();
		add(chequingDepositAmount);
		confirmDepositChequing = new JButton("Confirm Deposit");
		add(confirmDepositChequing);
		
		add(new JLabel("Savings: Balance"));
		savingsDepositAmount = new TextField();
		add(savingsDepositAmount);
		confirmDepositSavings = new JButton("Confirm Deposit");
		add(confirmDepositSavings);
		
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectBack = new JButton("Back");
		add(selectBack);
		add(new JLabel(""));
		selectBack.addActionListener(new backButtonListener());
	
		}
	
public void transferPage() {
		
		setLayout(new GridLayout(0, 3));
		add(new JLabel("Banking Simulator"));
		add(new JLabel(""));
		add(new JLabel("Welcome, Quinn"));
		
		add(new JLabel(""));
		add(new JLabel("Transfer Funds"));
		add(new JLabel(""));
		
		DefaultComboBoxModel<String> accountModel1 = new DefaultComboBoxModel<>();
        accountModel1.addElement(new String("Chequing"));
        accountModel1.addElement(new String("Savings"));
		add(new JLabel("Account to transfer from:"));
		transferFrom = new JComboBox(accountModel1);
		add(transferFrom);
		add(new JLabel(""));
		
		DefaultComboBoxModel<String> accountModel2 = new DefaultComboBoxModel<>();
        accountModel2.addElement(new String("Chequing"));
        accountModel2.addElement(new String("Savings"));
		add(new JLabel("Account to transfer to:"));
		transferTo = new JComboBox(accountModel2);
		add(transferTo);
		confirmTransfer = new JButton("Confirm Transfer");
		add(confirmTransfer);
		
		add(new JLabel(""));
		add(new JLabel(""));
		add(new JLabel(""));
		
		add(new JLabel(""));
		selectBack = new JButton("Back");
		add(selectBack);
		add(new JLabel(""));
		selectBack.addActionListener(new backButtonListener());
	
		}
	
	public void displayPage() {
		
		setTitle("Banking Simulator");  // "super" Frame sets title
	    setSize(600, 200);  // "super" Frame sets initial window size
	    setVisible(true);   // "super" Frame shows
	    setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	private class createAccountListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	String name = usernameInput.getText();
	    	String password = passwordInput.getText();
	    	//System.out.println(name + password);
	    	
	    	boolean uppercase = false;
	    	boolean symbol = false;
	    	boolean number = false;
	    	char checkPassword[] = password.toCharArray();
	    	for(int i = 0; i < password.length(); i++) {
	    		
	    		if(uppercase == false) 
	    			if(Character.isUpperCase(checkPassword[i]) == true)
	    				uppercase = true;		
	    		
	    		if(symbol == false)
	    			if(!Character.isDigit(checkPassword[i]) && !Character.isLetter(checkPassword[i]) && !Character.isWhitespace(checkPassword[i]))
	    				symbol = true;
	    		
	    		if(number == false)
	    			if(Character.isDigit(checkPassword[i]) == true)
	    				number = true;	
	    	}
	    	
	    	if(uppercase == true && symbol == true && number == true) {	
	    		//gather login info and store it
		    	getContentPane().removeAll();
		    	loginPage();
		    	validate();
	    	}
	    	
	    	else {
	    		creationError = true;
	    		getContentPane().removeAll();
		    	createLoginPage();
		    	validate();
	    	}
	    }
	 }
	
	private class loginListener implements ActionListener {
			
		    @Override
		    public void actionPerformed(ActionEvent evt) {
		    	String name = usernameInput.getText();
		    	String password = passwordInput.getText();
		    	
		    	getContentPane().removeAll();
		    	homePage();
		    	validate();
		    	
		 }
	

	}
	
	private class logOutListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	loggedOut = true;
	    	getContentPane().removeAll();
	    	loginPage();
	    	validate();
	    	
	    }
	}
	
	private class checkBalanceListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	getContentPane().removeAll();
	    	checkBalancePage();
	    	validate();
	    	
	    }
	}
	
	private class withdrawListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	getContentPane().removeAll();
	    	withdrawPage();
	    	validate();
	    	
	    }
	}
	
	private class depositListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	getContentPane().removeAll();
	    	depositPage();
	    	validate();
	    	
	    }
	}
	
	private class transferListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	getContentPane().removeAll();
	    	transferPage();
	    	validate();
	    	
	    }
	}
	
	private class backButtonListener implements ActionListener {
		
	    @Override
	    public void actionPerformed(ActionEvent evt) {
	    	getContentPane().removeAll();
	    	homePage();
	    	validate();
	    	
	    }
	}
	
}
