  
public class FactoryPlanController
{    
  
	public static void main(String argvs[])   {     
   
		SimulatorGUI test = new SimulatorGUI();
		test.createLoginPage();
		test.displayPage();
  
	}    
} 
